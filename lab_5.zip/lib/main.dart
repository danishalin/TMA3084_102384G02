import 'package:flutter/material.dart';

void main() {
  runApp(const Lab5());
}

class Lab5 extends StatelessWidget {
  const Lab5({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Android ATC Pizza Place'),
          backgroundColor: Colors.deepOrangeAccent,
          foregroundColor: Colors.white,
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              // First Card: Vegetable Pizza
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                margin: const EdgeInsets.all(10.0),
                color: Colors.deepOrangeAccent,
                elevation: 20.0,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        'images/pizza_1.png',
                        width: 100.0,
                        height: 100.0,
                      ),
                      const SizedBox(width: 20.0),
                      const Text(
                        'Vegetable Pizza',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 24.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Second Card: Cheese Pizza
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                margin: const EdgeInsets.all(10.0),
                color: Colors.deepOrangeAccent,
                elevation: 20.0,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        'images/pizza_2.png',
                        width: 100.0,
                        height: 100.0,
                      ),
                      const SizedBox(width: 20.0),
                      const Text(
                        'Cheese Pizza',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 24.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Third Card: Box of Fries
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                margin: const EdgeInsets.all(10.0),
                color: Colors.deepOrangeAccent,
                elevation: 20.0,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        'images/Fries.png',
                        width: 100.0,
                        height: 100.0,
                      ),
                      const SizedBox(width: 20.0),
                      const Text(
                        'Box of Fries',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 24.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}